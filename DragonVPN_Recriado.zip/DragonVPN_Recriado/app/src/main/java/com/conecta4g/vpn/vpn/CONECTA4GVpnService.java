package com.conecta4g.vpn.vpn;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import com.conecta4g.vpn.CONECTA4GMainActivity;
import com.conecta4g.vpn.R;
import java.io.IOException;

/**
 * CONECTA4G VPN Service
 * VERSÃO RECRIADA SEM CRIPTOGRAFIA - Código Aberto
 * 
 * Implementa o VpnService do Android para criar uma interface VPN
 * que encaminha o tráfego através do túnel SSH.
 */
public class CONECTA4GVpnService extends VpnService {

    private static final String CHANNEL_ID = "CONECTA4G_VPN_CHANNEL";
    private static final int NOTIFICATION_ID = 1;

    private ParcelFileDescriptor vpnInterface;
    private Thread vpnThread;
    private boolean isRunning = false;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            return START_NOT_STICKY;
        }

        String action = intent.getAction();
        if ("START".equals(action)) {
            startVpn();
        } else if ("STOP".equals(action)) {
            stopVpn();
        }

        return START_NOT_STICKY;
    }

    /**
     * Inicia a conexão VPN
     */
    private void startVpn() {
        if (isRunning) {
            return;
        }

        // Configura a interface VPN
        Builder builder = new Builder();
        builder.setSession("CONECTA4G VPN");
        builder.addAddress("10.0.0.2", 24);
        builder.addRoute("0.0.0.0", 0);
        builder.addDnsServer("8.8.8.8");
        builder.addDnsServer("8.8.4.4");
        builder.setMtu(1500);

        try {
            vpnInterface = builder.establish();
            if (vpnInterface == null) {
                return;
            }

            isRunning = true;

            // Inicia o serviço em primeiro plano com notificação
            startForeground(NOTIFICATION_ID, createNotification());

            // AQUI VOCÊ DEVE IMPLEMENTAR O TÚNEL SSH REAL
            // - Conecte ao servidor SSH usando JSch ou similar
            // - Configure o port forwarding
            // - Encaminhe o tráfego da interface VPN para o túnel SSH

            // Exemplo de implementação com JSch:
            // startSshTunnel();

        } catch (Exception e) {
            e.printStackTrace();
            stopVpn();
        }
    }

    /**
     * Para a conexão VPN
     */
    private void stopVpn() {
        isRunning = false;

        if (vpnThread != null) {
            vpnThread.interrupt();
            vpnThread = null;
        }

        if (vpnInterface != null) {
            try {
                vpnInterface.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            vpnInterface = null;
        }

        stopForeground(true);
        stopSelf();
    }

    /**
     * Cria o canal de notificação (Android 8+)
     */
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "CONECTA4G VPN",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Notificação de conexão VPN");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    /**
     * Cria a notificação de serviço em primeiro plano
     */
    private Notification createNotification() {
        Intent intent = new Intent(this, CONECTA4GMainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_IMMUTABLE
        );

        return new Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("CONECTA4G VPN")
            .setContentText("VPN está conectada")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pendingIntent)
            .build();
    }

    @Override
    public void onDestroy() {
        stopVpn();
        super.onDestroy();
    }
}
