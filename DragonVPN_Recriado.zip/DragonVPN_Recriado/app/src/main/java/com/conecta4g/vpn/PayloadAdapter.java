package com.conecta4g.vpn;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import org.json.JSONObject;
import java.util.ArrayList;

/**
 * Adapter para lista de payloads/networks
 * VERSÃO SEM CRIPTOGRAFIA - Código Aberto
 */
public class PayloadAdapter extends ArrayAdapter<JSONObject> {

    private final Context context;

    public PayloadAdapter(Context context, ArrayList<JSONObject> payloads) {
        super(context, R.layout.payload_item, payloads);
        this.context = context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return createView(position, parent);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return createView(position, parent);
    }

    private View createView(int position, ViewGroup parent) {
        View view = LayoutInflater.from(context).inflate(R.layout.payload_item, parent, false);
        TextView tvName = view.findViewById(R.id.payloadName);
        TextView tvType = view.findViewById(R.id.payloadType);

        try {
            JSONObject payload = getItem(position);
            if (payload != null) {
                String name = payload.optString("Name", "Payload");
                String type = payload.optString("Type", "");

                if ("PAYLOAD ALEATÓRIO".equals(name)) {
                    tvName.setText(R.string.random_payload);
                } else {
                    tvName.setText(name);
                }

                tvType.setText(type);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return view;
    }
}
