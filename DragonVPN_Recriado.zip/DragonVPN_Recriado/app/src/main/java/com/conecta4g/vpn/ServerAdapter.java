package com.conecta4g.vpn;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

/**
 * Adapter para lista de servidores
 * VERSÃO SEM CRIPTOGRAFIA - Código Aberto
 */
public class ServerAdapter extends ArrayAdapter<JSONObject> {

    private final Context context;
    private final ArrayList<JSONObject> servers;

    public ServerAdapter(Context context, ArrayList<JSONObject> servers) {
        super(context, R.layout.server_item, servers);
        this.context = context;
        this.servers = servers;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return createView(position, parent);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return createView(position, parent);
    }

    private View createView(int position, ViewGroup parent) {
        View view = LayoutInflater.from(context).inflate(R.layout.server_item, parent, false);
        TextView tvName = view.findViewById(R.id.itemName);
        TextView tvExtra = view.findViewById(R.id.textExtra);
        ImageView imgFlag = view.findViewById(R.id.itemImage);

        try {
            JSONObject server = getItem(position);
            if (server != null) {
                String name = server.optString("Name", "Servidor");
                String country = server.optString("Country", "");
                String type = server.optString("Type", "");

                // Configura nome
                if ("SERVIDOR ALEATÓRIO".equals(name)) {
                    tvName.setText(R.string.random_server);
                } else {
                    tvName.setText(name);
                }

                // Configura tipo (Free/Premium)
                tvExtra.setText(type);
                if ("Free".equalsIgnoreCase(type)) {
                    tvExtra.setTextColor(0xFF00FF00); // Verde
                } else if ("Premium".equalsIgnoreCase(type)) {
                    tvExtra.setTextColor(0xFFFFD700); // Dourado
                } else {
                    tvExtra.setTextColor(0xFFFF0000); // Vermelho
                }

                // Carrega bandeira
                loadFlag(imgFlag, country);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return view;
    }

    /**
     * Carrega a imagem da bandeira dos assets
     */
    private void loadFlag(ImageView imageView, String countryCode) {
        try {
            AssetManager assets = context.getAssets();
            String flagPath = "flags/" + countryCode.toLowerCase() + ".png";
            InputStream is = assets.open(flagPath);
            Drawable drawable = Drawable.createFromStream(is, countryCode);
            imageView.setImageDrawable(drawable);
            is.close();
        } catch (IOException e) {
            // Se não encontrar a bandeira, usa uma padrão
            imageView.setImageResource(android.R.drawable.ic_menu_gallery);
        }
    }
}
