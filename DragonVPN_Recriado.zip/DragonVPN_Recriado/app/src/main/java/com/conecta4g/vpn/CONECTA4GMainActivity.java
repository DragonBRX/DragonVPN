package com.conecta4g.vpn;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;

/**
 * CONECTA4G Main Activity
 * VERSÃO RECRIADA SEM CRIPTOGRAFIA - Código Aberto
 * 
 * Funcionalidades:
 * - Seleção de servidor SSH
 * - Seleção de payload
 * - Conexão VPN
 * - Config carregada de assets/config/config.json (sem criptografia)
 */
public class CONECTA4GMainActivity extends AppCompatActivity {

    private Spinner spinnerServer;
    private Spinner spinnerPayload;
    private Button btnConnect;
    private Button btnDisconnect;
    private EditText etUser;
    private EditText etPass;
    private TextView tvStatus;
    private TextView tvLog;

    private ConfigManager configManager;
    private ServerAdapter serverAdapter;
    private PayloadAdapter payloadAdapter;

    private ArrayList<JSONObject> servers = new ArrayList<>();
    private ArrayList<JSONObject> payloads = new ArrayList<>();

    private JSONObject selectedServer = null;
    private JSONObject selectedPayload = null;

    private boolean isConnected = false;

    // SharedPreferences
    private SharedPreferences prefs;
    private static final String PREFS_NAME = "CONECTA4G_PREFS";
    private static final String KEY_LAST_SERVER = "LastSelectedServer";
    private static final String KEY_LAST_PAYLOAD = "LastSelectedPayload";
    private static final String KEY_SAVED_USER = "SavedUser";
    private static final String KEY_SAVED_PASS = "SavedPass";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializa ConfigManager (SEM CRIPTOGRAFIA)
        configManager = new ConfigManager(this);
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Inicializa views
        initViews();

        // Carrega configurações
        loadServers();
        loadPayloads();

        // Configura spinners
        setupSpinners();

        // Configura botões
        setupButtons();

        // Restaura seleções salvas
        restoreSelections();
    }

    private void initViews() {
        spinnerServer = findViewById(R.id.spinnerServer);
        spinnerPayload = findViewById(R.id.spinnerPayload);
        btnConnect = findViewById(R.id.btnConnect);
        btnDisconnect = findViewById(R.id.btnDisconnect);
        etUser = findViewById(R.id.etUser);
        etPass = findViewById(R.id.etPass);
        tvStatus = findViewById(R.id.tvStatus);
        tvLog = findViewById(R.id.tvLog);
    }

    /**
     * Carrega servidores do config.json
     */
    private void loadServers() {
        servers.clear();
        JSONArray serversArray = configManager.getServers();
        for (int i = 0; i < serversArray.length(); i++) {
            try {
                servers.add(serversArray.getJSONObject(i));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        serverAdapter = new ServerAdapter(this, servers);
        spinnerServer.setAdapter(serverAdapter);
    }

    /**
     * Carrega payloads do config.json
     */
    private void loadPayloads() {
        payloads.clear();
        JSONArray networksArray = configManager.getNetworks();
        for (int i = 0; i < networksArray.length(); i++) {
            try {
                payloads.add(networksArray.getJSONObject(i));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        payloadAdapter = new PayloadAdapter(this, payloads);
        spinnerPayload.setAdapter(payloadAdapter);
    }

    /**
     * Configura listeners dos spinners
     */
    private void setupSpinners() {
        spinnerServer.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < servers.size()) {
                    selectedServer = servers.get(position);
                    prefs.edit().putInt(KEY_LAST_SERVER, position).apply();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        spinnerPayload.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < payloads.size()) {
                    selectedPayload = payloads.get(position);
                    prefs.edit().putInt(KEY_LAST_PAYLOAD, position).apply();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    /**
     * Configura listeners dos botões
     */
    private void setupButtons() {
        btnConnect.setOnClickListener(v -> attemptConnection());
        btnDisconnect.setOnClickListener(v -> disconnect());
    }

    /**
     * Restaura seleções salvas
     */
    private void restoreSelections() {
        int lastServer = prefs.getInt(KEY_LAST_SERVER, 0);
        int lastPayload = prefs.getInt(KEY_LAST_PAYLOAD, 0);

        if (lastServer < servers.size()) {
            spinnerServer.setSelection(lastServer);
        }
        if (lastPayload < payloads.size()) {
            spinnerPayload.setSelection(lastPayload);
        }
    }

    /**
     * Tenta estabelecer conexão VPN
     */
    private void attemptConnection() {
        if (selectedServer == null || selectedPayload == null) {
            Toast.makeText(this, "Selecione um servidor e payload!", Toast.LENGTH_SHORT).show();
            return;
        }

        String user = etUser.getText().toString().trim();
        String pass = etPass.getText().toString().trim();

        if (user.isEmpty() || pass.isEmpty()) {
            Toast.makeText(this, "Informe usuário e senha!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Salva credenciais
        prefs.edit()
            .putString(KEY_SAVED_USER, user)
            .putString(KEY_SAVED_PASS, pass)
            .apply();

        // Inicia conexão
        String serverHost = selectedServer.optString("Host", "");
        int serverPort = selectedServer.optInt("Port", 22);
        String payload = selectedPayload.optString("Payload", "");

        tvStatus.setText("Status: Conectando...");
        tvStatus.setTextColor(0xFFFFFF00); // Amarelo
        log("Conectando a " + serverHost + ":" + serverPort);
        log("Payload: " + payload);

        // AQUI VOCÊ DEVE IMPLEMENTAR A CONEXÃO SSH/VPN REAL
        // Use a biblioteca UltraSSH ou implemente sua própria conexão
        // Exemplo:
        // startVpnService(serverHost, serverPort, user, pass, payload);

        // Simulação de conexão bem-sucedida
        tvStatus.setText("Status: CONECTADO");
        tvStatus.setTextColor(0xFF00FF00); // Verde
        isConnected = true;
        updateButtonStates();

        Toast.makeText(this, "Conectado!", Toast.LENGTH_SHORT).show();
    }

    /**
     * Desconecta do servidor
     */
    private void disconnect() {
        // AQUI VOCÊ DEVE IMPLEMENTAR A DESCONEXÃO REAL
        // stopVpnService();

        tvStatus.setText("Status: Desconectado");
        tvStatus.setTextColor(0xFFFF0000); // Vermelho
        isConnected = false;
        updateButtonStates();

        Toast.makeText(this, "Desconectado!", Toast.LENGTH_SHORT).show();
    }

    private void updateButtonStates() {
        btnConnect.setEnabled(!isConnected);
        btnDisconnect.setEnabled(isConnected);
    }

    private void log(String message) {
        tvLog.append(message + "\n");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isConnected) {
            disconnect();
        }
    }
}
