package com.conecta4g.vpn;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * ConfigManager - Carrega e gerencia o config.json
 * VERSÃO SEM CRIPTOGRAFIA - Código Aberto
 */
public class ConfigManager {

    private static final String CONFIG_FILE = "Config.json";
    private static final String ASSETS_CONFIG = "config/config.json";
    private final Context context;
    private JSONObject config;

    public ConfigManager(Context context) {
        this.context = context;
        loadConfig();
    }

    /**
     * Carrega o config.json dos arquivos internos ou dos assets
     */
    private void loadConfig() {
        try {
            // Tenta carregar do arquivo interno primeiro (para updates)
            File file = new File(context.getFilesDir(), CONFIG_FILE);
            String jsonStr;
            if (file.exists()) {
                jsonStr = readStream(new FileInputStream(file));
            } else {
                // Carrega dos assets
                jsonStr = readStream(context.getAssets().open(ASSETS_CONFIG));
            }
            config = new JSONObject(jsonStr);
        } catch (Exception e) {
            e.printStackTrace();
            config = new JSONObject();
        }
    }

    /**
     * Lê um InputStream para uma String
     */
    private String readStream(InputStream inputStream) {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
            char[] buffer = new char[1024];
            int read;
            while ((read = reader.read(buffer, 0, 1024)) > 0) {
                sb.append(buffer, 0, read);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }

    /**
     * Retorna o JSONObject completo
     */
    public JSONObject getConfig() {
        return config;
    }

    /**
     * Retorna o array de servidores
     */
    public JSONArray getServers() {
        try {
            if (config != null && config.has("Servers")) {
                return config.getJSONArray("Servers");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return new JSONArray();
    }

    /**
     * Retorna o array de payloads/networks
     */
    public JSONArray getNetworks() {
        try {
            if (config != null && config.has("Networks")) {
                return config.getJSONArray("Networks");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return new JSONArray();
    }

    /**
     * Retorna uma string do config
     */
    public String getString(String key) {
        try {
            if (config != null && config.has(key)) {
                return config.getString(key);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * Retorna um boolean do config
     */
    public boolean getBoolean(String key, boolean defaultValue) {
        try {
            if (config != null && config.has(key)) {
                return config.getBoolean(key);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return defaultValue;
    }

    /**
     * Retorna um int do config
     */
    public int getInt(String key, int defaultValue) {
        try {
            if (config != null && config.has(key)) {
                return config.getInt(key);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return defaultValue;
    }

    /**
     * Salva uma configuração atualizada nos arquivos internos
     */
    public void saveConfig(String jsonStr) {
        try {
            File file = new File(context.getFilesDir(), CONFIG_FILE);
            java.io.FileOutputStream fos = new java.io.FileOutputStream(file);
            fos.write(jsonStr.getBytes());
            fos.flush();
            fos.close();
            // Recarrega o config
            config = new JSONObject(jsonStr);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
