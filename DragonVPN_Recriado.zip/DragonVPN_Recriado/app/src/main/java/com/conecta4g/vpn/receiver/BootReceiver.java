package com.conecta4g.vpn.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * BootReceiver - Reinicia o serviço VPN após reinicialização do dispositivo
 * VERSÃO RECRIADA SEM CRIPTOGRAFIA - Código Aberto
 */
public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            // Aqui você pode reiniciar o serviço VPN se necessário
            // Intent serviceIntent = new Intent(context, CONECTA4GVpnService.class);
            // serviceIntent.setAction("START");
            // context.startService(serviceIntent);
        }
    }
}
