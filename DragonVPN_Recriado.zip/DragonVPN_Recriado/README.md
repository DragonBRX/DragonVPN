# CONECTA4G VPN - VERSÃO RECRIADA (Código Aberto)

## Descrição

Esta é uma versão recriada do aplicativo **CONECTA4G VPN** completamente em **código aberto**, sem criptografia, baseada na análise do APK original.

## Análise do APK Original

### Estrutura Encontrada
- **Pacote**: `com.conecta4g.vpn`
- **MainActivity**: `CONECTA4GMainActivity`
- **Serviço VPN**: `com.ultrasshservice.CONECTA4GService`
- **Biblioteca SSH**: `com.trilead.ssh2` (JSch)
- **Proteção**: LIAPP (LI APPlication Protection)

### Sistema de Criptografia Original

O APK original usava **criptografia em múltiplas camadas**:

#### 1. Criptografia do config.json
- **Algoritmo**: AES/ECB/PKCS5Padding
- **Chave**: Derivada de uma string ofuscada pela classe `com.liapp.y`
- **Processo de derivação da chave**:
  1. String é **revertida**
  2. Convertida para bytes **UTF-8**
  3. Concatenada com bytes `{77, 65, 61, 61}` (="MA==")
  4. Aplicado **SHA-256**
  5. Usados os primeiros **32 bytes** como chave AES-256
- **Arquivo**: `assets/config/config.json` (Base64 encoded)

#### 2. Criptografia do SharedPreferences
- **Algoritmo**: AES-CBC com PBKDF2/SHA256
- **Classe**: `e4/a.java` (SharedPreferences criptografado)
- **Chave**: Derivada via `z3/b.java`

#### 3. Proteção LIAPP
- **classes.dex**: DEX principal (válido)
- **classes2.dex**: DEX secundário **corrompido/protegido**
  - Contém a classe `com.liapp.y` (strings ofuscadas)
  - Estrutura DEX criptografada/ofuscada
  - Dois DEXs concatenados com header corrompido

### Estrutura do config.json (Descriptografado)

```json
{
  "Servers": [
    {
      "Name": "SERVIDOR ALEATÓRIO",
      "Country": "aleatorio",
      "Type": "Random"
    },
    {
      "Name": "Brasil - São Paulo",
      "Host": "sp1.conecta4g.example",
      "Port": 22,
      "Country": "br",
      "Type": "Free"
    }
  ],
  "Networks": [
    {
      "Name": "PAYLOAD ALEATÓRIO",
      "Type": "Random"
    },
    {
      "Name": "Claro - Direct",
      "Type": "Direct",
      "Payload": "GET / HTTP/1.1\r\nHost: [host]\r\n..."
    }
  ],
  "Aviso": true,
  "HtmlSuport": false,
  "MsgAviso": "Mensagem de aviso",
  "Alert": false,
  "Image": false,
  "ImgUrl": "",
  "CurrentId": 1,
  "SaveId": false,
  "Title": "Aviso",
  "Text": "Texto do aviso",
  "UrlSuporte": false,
  "EnableCancel": true,
  "SetCancelable": true,
  "PushNotification": false,
  "TextConfirmar": "OK",
  "TextCancel": "Cancelar",
  "Url": "https://example.com"
}
```

## Estrutura do Projeto Recriado

```
DragonVPN_Recriado/
├── app/
│   ├── build.gradle              # Configuração do build
│   └── src/main/
│       ├── AndroidManifest.xml   # Manifesto
│       ├── assets/
│       │   ├── config/
│       │   │   └── config.json  # Config SEM CRIPTOGRAFIA
│       │   └── flags/            # Bandeiras de países
│       ├── java/com/conecta4g/vpn/
│       │   ├── CONECTA4GMainActivity.java  # Activity principal
│       │   ├── ConfigManager.java          # Gerenciador de config
│       │   ├── ServerAdapter.java          # Adapter de servidores
│       │   ├── PayloadAdapter.java         # Adapter de payloads
│       │   ├── vpn/
│       │   │   └── CONECTA4GVpnService.java # Serviço VPN
│       │   └── receiver/
│       │       └── BootReceiver.java       # Receiver de boot
│       └── res/
│           ├── layout/
│           │   ├── activity_main.xml    # Layout principal
│           │   ├── server_item.xml      # Item de servidor
│           │   └── payload_item.xml     # Item de payload
│           └── values/
│               └── strings.xml          # Strings
└── README.md                        # Este arquivo
```

## Como Usar

### 1. Configurar o config.json

Edite o arquivo `app/src/main/assets/config/config.json` e adicione seus servidores SSH:

```json
{
  "Servers": [
    {
      "Name": "Meu Servidor",
      "Host": "seu_servidor.com",
      "Port": 443,
      "Country": "br",
      "Type": "Premium"
    }
  ],
  "Networks": [
    {
      "Name": "Minha Operadora",
      "Type": "Direct",
      "Payload": "GET / HTTP/1.1\r\nHost: [host]\r\nConnection: Keep-Alive\r\n\r\n"
    }
  ]
}
```

### 2. Compilar com Android Studio

1. Abra o projeto no Android Studio
2. Sincronize o Gradle
3. Compile e execute no dispositivo

### 3. Compilar com MT Manager

1. Copie o projeto para seu dispositivo
2. Abra o MT Manager
3. Navegue até o projeto
4. Compile o APK diretamente

## Melhorias Implementadas (Sem Criptografia)

| Recurso | Original | Recriado |
|---------|----------|----------|
| Configuração | Criptografada (AES/ECB) | **JSON aberto** |
| Chave de criptografia | Ofuscada em `com.liapp.y` | **Removida** |
| SharedPreferences | Criptografado (AES-CBC) | **Padrão Android** |
| Proteção LIAPP | classes2.dex corrompido | **Código limpo** |
| Strings | Ofuscadas | **Claras e documentadas** |

## O que Você Precisa Implementar

### 1. Conexão SSH Real

O projeto inclui a estrutura básica, mas **você precisa implementar a conexão SSH real**. Exemplo com JSch:

```java
import com.jcraft.jsch.*;

public void connectSsh(String host, int port, String user, String pass) {
    try {
        JSch jsch = new JSch();
        Session session = jsch.getSession(user, host, port);
        session.setPassword(pass);
        
        // Configura proxy/payload se necessário
        Properties config = new Properties();
        config.put("StrictHostKeyChecking", "no");
        session.setConfig(config);
        
        session.connect(30000); // 30 segundos timeout
        
        // Configura port forwarding
        session.setPortForwardingL(1080, "localhost", 1080);
        
    } catch (Exception e) {
        e.printStackTrace();
    }
}
```

### 2. Integração VPN + SSH

Você precisa integrar o `VpnService` com o túnel SSH para que o tráfego do dispositivo seja roteado através do túnel.

### 3. Payloads HTTP

Implemente o sistema de injeção de payloads HTTP para operadoras específicas.

## Config JSON - Campos Disponíveis

### Servers (Servidores SSH)

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `Name` | String | Nome exibido no spinner |
| `Host` | String | Endereço do servidor SSH |
| `Port` | Int | Porta SSH (22, 443, etc) |
| `User` | String | Usuário SSH (opcional) |
| `Pass` | String | Senha SSH (opcional) |
| `Country` | String | Código do país (br, us, etc) |
| `Type` | String | Tipo: Free, Premium, Random |

### Networks (Payloads)

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `Name` | String | Nome exibido no spinner |
| `Type` | String | Tipo: Direct, SSL, Proxy, Random |
| `Payload` | String | Payload HTTP para injeção |

### Configurações Gerais

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `Aviso` | Boolean | Habilitar aviso no topo |
| `MsgAviso` | String | Texto do aviso |
| `Alert` | Boolean | Mostrar alerta/dialog |
| `Title` | String | Título do alerta |
| `Text` | String | Texto do alerta |
| `Url` | String | URL de suporte |
| `EnableCancel` | Boolean | Botão cancelar no alerta |
| `SetCancelable` | Boolean | Alerta cancelável |
| `PushNotification` | Boolean | Notificação push |

## Notas Técnicas

### Por que a senha não foi descoberta?

A senha de criptografia está protegida pela **LIAPP (LI APPlication Protection)**, que:
1. Criptografa o `classes2.dex` com uma chave dinâmica
2. Ofusca as strings usando uma tabela de lookup em tempo de execução
3. Implementa anti-tampering e anti-debugging

A classe `com.liapp.y` que contém as strings ofuscadas está no `classes2.dex` que está **criptografado e corrompido** propositalmente. Sem a chave LIAPP original, não é possível extrair as strings.

### Solução Adotada

Em vez de quebrar a criptografia (que seria extremamente difícil), optamos por **recriar o aplicativo do zero** com:
- Código limpo e documentado
- Configuração em JSON aberto
- Mesma estrutura e funcionalidades
- Pronto para personalização

## Aviso Legal

Este projeto é apenas para **fins educacionais**. O uso de VPNs e túneis SSH pode estar sujeito a:
- Termos de serviço da sua operadora
- Leis locais de telecomunicações
- Políticas de uso aceitável

Use por sua própria conta e risco.

## Licença

Código aberto - Livre para uso e modificação.

---

**Análise e recriação feita em**: 2026-04-22
**Baseado no APK**: CONECTA4G_36.apk (v3.6)
